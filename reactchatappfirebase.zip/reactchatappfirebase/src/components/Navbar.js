import React from 'react'
import { auth } from '../firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import Signin from './Signin';
import Signout from './Signout';

const style={
nav:`bg-gray-800 h-20 flex justify-between item-center p-4`,
heading:`text-white text-3xl`
}

const Navbar = () => {
    const [user] = useAuthState(auth);
    console.log(user);
  return (
    <div className={style.nav}>
        <h1 className={style.heading}>Chat Application</h1>
        {user ? <Signout></Signout> : <Signin></Signin>}
    </div>
  );
};

export default Navbar;